const fs = require('fs')
fs.writeFileSync('notes.txt', 'I live in Philadelphia')
